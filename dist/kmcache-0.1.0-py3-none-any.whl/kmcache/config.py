"""Configuration models for kmcache."""

from __future__ import annotations

from dataclasses import dataclass, field

from kmcache.constants import (
    DEFAULT_BROADCAST_CHANNEL,
    DEFAULT_CACHE_NAME,
    DEFAULT_CIRCUIT_FAILURE_THRESHOLD,
    DEFAULT_CIRCUIT_HALF_OPEN_MAX_CALLS,
    DEFAULT_CIRCUIT_RECOVERY_TIMEOUT,
    DEFAULT_LOCAL_MAX_SIZE,
    DEFAULT_NAMESPACE,
    DEFAULT_NULL_TTL,
    DEFAULT_REDIS_TIMEOUT,
    DEFAULT_TTL,
    DEFAULT_TTL_JITTER,
)


@dataclass(slots=True)
class LocalCacheConfig:
    """L1 本地缓存配置。"""

    enabled: bool = True
    name: str = "l1"
    max_size: int = DEFAULT_LOCAL_MAX_SIZE
    default_ttl: int = DEFAULT_TTL

    def __post_init__(self) -> None:
        """初始化后校验本地缓存配置。

        参数:
            无。

        返回:
            None。
        """

        if self.max_size <= 0:
            msg = "local.max_size must be greater than 0"
            raise ValueError(msg)
        if self.default_ttl <= 0:
            msg = "local.default_ttl must be greater than 0"
            raise ValueError(msg)


@dataclass(slots=True)
class RedisCacheConfig:
    """L2 Redis 缓存配置。"""

    enabled: bool = True
    name: str = "l2"
    url: str = "redis://localhost:6379/0"
    key_prefix: str = DEFAULT_CACHE_NAME
    socket_timeout: float = DEFAULT_REDIS_TIMEOUT
    lock_timeout: float = 5.0
    lock_sleep_interval: float = 0.05

    def __post_init__(self) -> None:
        """初始化后校验 Redis 缓存配置。

        参数:
            无。

        返回:
            None。
        """

        if not self.url:
            msg = "redis.url must not be empty"
            raise ValueError(msg)
        if self.socket_timeout <= 0:
            msg = "redis.socket_timeout must be greater than 0"
            raise ValueError(msg)
        if self.lock_timeout <= 0:
            msg = "redis.lock_timeout must be greater than 0"
            raise ValueError(msg)
        if self.lock_sleep_interval <= 0:
            msg = "redis.lock_sleep_interval must be greater than 0"
            raise ValueError(msg)


@dataclass(slots=True)
class BroadcastConfig:
    """广播失效通知配置。"""

    enabled: bool = False
    channel: str = DEFAULT_BROADCAST_CHANNEL
    instance_id: str = "local-instance"

    def __post_init__(self) -> None:
        """初始化后校验广播配置。

        参数:
            无。

        返回:
            None。
        """

        if self.enabled and not self.channel:
            msg = "broadcast.channel must not be empty when broadcast is enabled"
            raise ValueError(msg)
        if not self.instance_id:
            msg = "broadcast.instance_id must not be empty"
            raise ValueError(msg)


@dataclass(slots=True)
class CircuitBreakerConfig:
    """熔断器配置。"""

    enabled: bool = True
    failure_threshold: int = DEFAULT_CIRCUIT_FAILURE_THRESHOLD
    recovery_timeout: float = DEFAULT_CIRCUIT_RECOVERY_TIMEOUT
    half_open_max_calls: int = DEFAULT_CIRCUIT_HALF_OPEN_MAX_CALLS

    def __post_init__(self) -> None:
        """初始化后校验熔断器配置。

        参数:
            无。

        返回:
            None。
        """

        if self.failure_threshold <= 0:
            msg = "circuit_breaker.failure_threshold must be greater than 0"
            raise ValueError(msg)
        if self.recovery_timeout <= 0:
            msg = "circuit_breaker.recovery_timeout must be greater than 0"
            raise ValueError(msg)
        if self.half_open_max_calls <= 0:
            msg = "circuit_breaker.half_open_max_calls must be greater than 0"
            raise ValueError(msg)


@dataclass(slots=True)
class WarmupConfig:
    """缓存预热任务配置。"""

    enabled: bool = True
    run_on_startup: bool = False
    interval_seconds: float | None = None

    def __post_init__(self) -> None:
        """初始化后校验预热配置。

        参数:
            无。

        返回:
            None。
        """

        if self.interval_seconds is not None and self.interval_seconds <= 0:
            msg = "warmup.interval_seconds must be greater than 0"
            raise ValueError(msg)


@dataclass(slots=True)
class CacheConfig:
    """缓存管理器顶层配置。"""

    enabled: bool = True
    namespace: str = DEFAULT_NAMESPACE
    key_prefix: str = DEFAULT_CACHE_NAME
    default_ttl: int = DEFAULT_TTL
    default_soft_ttl: int | None = None
    ttl_jitter: int = DEFAULT_TTL_JITTER
    null_ttl: int = DEFAULT_NULL_TTL
    enable_stale: bool = True
    enable_null_cache: bool = True
    local: LocalCacheConfig = field(default_factory=LocalCacheConfig)
    redis: RedisCacheConfig = field(default_factory=RedisCacheConfig)
    broadcast: BroadcastConfig = field(default_factory=BroadcastConfig)
    circuit_breaker: CircuitBreakerConfig = field(default_factory=CircuitBreakerConfig)
    warmup: WarmupConfig = field(default_factory=WarmupConfig)

    def __post_init__(self) -> None:
        """初始化后校验全局缓存配置。

        参数:
            无。

        返回:
            None。
        """

        if not self.namespace:
            msg = "namespace must not be empty"
            raise ValueError(msg)
        if self.default_ttl <= 0:
            msg = "default_ttl must be greater than 0"
            raise ValueError(msg)
        if self.default_soft_ttl is not None and self.default_soft_ttl <= 0:
            msg = "default_soft_ttl must be greater than 0"
            raise ValueError(msg)
        if self.ttl_jitter < 0:
            msg = "ttl_jitter must be greater than or equal to 0"
            raise ValueError(msg)
        if self.null_ttl <= 0:
            msg = "null_ttl must be greater than 0"
            raise ValueError(msg)
