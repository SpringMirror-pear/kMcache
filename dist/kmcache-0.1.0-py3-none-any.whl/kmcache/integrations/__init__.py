"""Framework integrations for kmcache."""
