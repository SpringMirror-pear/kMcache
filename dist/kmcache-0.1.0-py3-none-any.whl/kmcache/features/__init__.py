"""Cross-cutting cache features."""
